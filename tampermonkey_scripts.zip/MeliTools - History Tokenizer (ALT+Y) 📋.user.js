// ==UserScript==
// @name         MeliTools - History Tokenizer (ALT+Y) 📋
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  Captura e tokeniza o "Histórico do pacote" em JSON. ALT+Y = copia para clipboard.
// @author       You
// @match        https://envios.adminml.com/logistics/package-management/package/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    // =============================================
    // MESES PT-BR → número
    // =============================================
    const MONTHS_MAP = {
        jan: '01', fev: '02', mar: '03', abr: '04',
        mai: '05', jun: '06', jul: '07', ago: '08',
        set: '09', out: '10', nov: '11', dez: '12'
    };

    // =============================================
    // PARSER — Extrai metadados da página
    // =============================================
    function getPackageId() {
        const m = window.location.pathname.match(/package\/(\d+)/);
        return m?.[1] || null;
    }

    function getPageMeta() {
        const body = document.body.innerText;

        // Status principal (primeira linha de status visível)
        const statusMatch = body.match(/(?:ID do envio\s*\d+\s*Ver no Backoffice\s*Ver no Audit-Trail\s*)(\S[\s\S]*?)(?:\s*Origem)/i);
        let currentStatus = null;
        if (statusMatch) {
            currentStatus = statusMatch[1].trim();
        } else {
            // Fallback: procurar entre "Audit-Trail" e "Origem"
            const fallback = body.match(/Audit-Trail\s*(.+?)\s*Origem/);
            if (fallback) currentStatus = fallback[1].trim();
        }

        // Origem
        const originMatch = body.match(/Origem\s*(BR\w+)/i);

        // Promessa
        const promiseMatch = body.match(/Promessa de entrega\s*([\d\/\w\s\-]+?)(?:\s*Cancelar)/i);

        return {
            packageId: getPackageId(),
            currentStatus: currentStatus,
            origin: originMatch?.[1]?.trim() || null,
            promise: promiseMatch?.[1]?.trim() || null,
            url: window.location.href
        };
    }

    // =============================================
    // TOKENIZER — Extrai histórico completo
    // =============================================
    function tokenizeHistory() {
        const body = document.body.innerText;
        const lines = body.split('\n');
        const dateRegex = /(\d{2})\/(\w{3})\s+(\d{2}:\d{2})\s*hs/;

        let inHistory = false;
        const rawLines = [];
        let buffer = '';

        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) continue;

            // Detectar início da seção
            if (trimmed.includes('Histórico do pacote') || trimmed.includes('Atualizações de status')) {
                inHistory = true;
                continue;
            }

            // Ignorar aviso fixo
            if (trimmed.includes('A mudança de estado pode ser refletida')) continue;

            if (!inHistory) continue;

            // Se a linha contém uma data, é um novo evento
            if (dateRegex.test(trimmed)) {
                if (buffer) rawLines.push(buffer.trim());
                buffer = trimmed;
            } else if (buffer && trimmed) {
                // Continuação do evento anterior
                buffer += ' ' + trimmed;
            }
        }
        if (buffer) rawLines.push(buffer.trim());

        // Agora tokenizar cada linha
        const tokens = [];

        for (let i = 0; i < rawLines.length; i++) {
            const raw = rawLines[i];
            const token = parseLine(raw, i);
            tokens.push(token);
        }

        return tokens;
    }

    function parseLine(raw, index) {
        const dateRegex = /(\d{2})\/(\w{3})\s+(\d{2}:\d{2})\s*hs/;
        const dateMatch = raw.match(dateRegex);

        // === DATA ===
        let datetime = null;
        let dateISO = null;
        if (dateMatch) {
            const day = dateMatch[1];
            const monthStr = dateMatch[2].toLowerCase();
            const time = dateMatch[3];
            const monthNum = MONTHS_MAP[monthStr] || '??';
            const year = new Date().getFullYear();
            datetime = `${day}/${monthStr} ${time}`;
            dateISO = `${year}-${monthNum}-${day}T${time}:00`;
        }

        // === STATUS PRINCIPAL ===
        // Extrair o que vem depois do "hs |"
        let statusRaw = null;
        const afterPipe = raw.match(/hs\s*\|\s*(.+)/);
        if (afterPipe) {
            statusRaw = afterPipe[1].trim();
        }

        // === CLASSIFICAÇÃO ===
        const lower = raw.toLowerCase();
        let status = null;
        let subStatus = null;
        let isTransit = false;
        let facility = null;
        let route = null;
        let hasViewUpdate = false;

        // Detectar "Ver atualização"
        hasViewUpdate = lower.includes('ver atualização') || lower.includes('ver atualiza');

        // Limpar "Ver atualização" do statusRaw
        if (statusRaw) {
            statusRaw = statusRaw.replace(/Ver atualização/gi, '').trim();
        }

        // Detectar trânsito "No nó" + "Transita por FACILITY"
        if (lower.includes('no nó') && lower.includes('transita por')) {
            isTransit = true;
            status = 'no_no';
            const facilityMatch = raw.match(/Transita por\s+(.+?)(?:\s*$)/i);
            if (facilityMatch) {
                facility = facilityMatch[1].trim().replace(/Ver atualização/gi, '').trim();
            }
        }
        // Falha de entrega com motivo
        else if (lower.includes('falha de entrega')) {
            status = 'falha_de_entrega';
            const motivoMatch = raw.match(/Falha de entrega\s*\|\s*(.+?)(?:\s*Ruta|\s*Ver|\s*$)/i);
            if (motivoMatch) {
                subStatus = motivoMatch[1].trim();
            }
        }
        // Em rota
        else if (lower.includes('em rota de entrega')) {
            status = 'em_rota_de_entrega';
        }
        // Pronto para a rota
        else if (lower.includes('pronto para a rota')) {
            status = 'pronto_para_rota';
        }
        // No carrinho
        else if (lower.includes('no carrinho')) {
            status = 'no_carrinho';
        }
        // Para despachar
        else if (lower.includes('para despachar')) {
            status = 'para_despachar';
        }
        // Parado na estação
        else if (lower.includes('parado na esta')) {
            status = 'parado_na_estacao';
        }
        // Caminho para a estação
        else if (lower.includes('caminho para a esta')) {
            status = 'caminho_para_estacao';
        }
        // Entregue
        else if (lower.includes('entregue')) {
            status = 'entregue';
        }
        // Para devolução
        else if (lower.includes('para devolução') || lower.includes('para devolu')) {
            status = 'para_devolucao';
        }
        // Devolvido
        else if (lower.includes('devolvido')) {
            status = 'devolvido';
        }
        // Cancelado
        else if (lower.includes('cancelado')) {
            status = 'cancelado';
        }
        // Extraviado
        else if (lower.includes('extraviado')) {
            status = 'extraviado';
        }

        // Detectar rota
        const routeMatch = raw.match(/Ruta\s+(\d+)/i);
        if (routeMatch) route = routeMatch[1];

        // Detectar facility (quando não é trânsito)
        if (!facility) {
            const fMatch = raw.match(/(SERVICE_CENTER\s+\w+|NEX\s+\w+)/i);
            if (fMatch) facility = fMatch[1].trim();
        }

        return {
            index,
            datetime,
            dateISO,
            status,
            subStatus,
            isTransit,
            facility,
            route,
            hasViewUpdate,
            raw: raw
        };
    }

    // =============================================
    // BUILD FINAL JSON
    // =============================================
    function buildJSON() {
        const meta = getPageMeta();
        const history = tokenizeHistory();

        return {
            _generated: new Date().toISOString(),
            _script: 'MeliTools History Tokenizer v1.0.0',
            package: {
                id: meta.packageId,
                currentStatus: meta.currentStatus,
                origin: meta.origin,
                promise: meta.promise,
                url: meta.url
            },
            history: {
                totalEvents: history.length,
                events: history
            }
        };
    }

    // =============================================
    // COPY TO CLIPBOARD + TOAST
    // =============================================
    async function copyJSON() {
        const data = buildJSON();
        const json = JSON.stringify(data, null, 2);

        try {
            await navigator.clipboard.writeText(json);
            showToast('success', `✅ JSON copiado! (${data.history.totalEvents} eventos)`);
            console.log('[Tokenizer] JSON copiado:', data);
        } catch (err) {
            // Fallback
            const ta = document.createElement('textarea');
            ta.value = json;
            ta.style.cssText = 'position:fixed;top:-9999px;';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast('success', `✅ JSON copiado! (${data.history.totalEvents} eventos)`);
            console.log('[Tokenizer] JSON copiado (fallback):', data);
        }
    }

    // =============================================
    // TOAST NOTIFICATION
    // =============================================
    function showToast(type, message) {
        const existing = document.getElementById('tokenizer-toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.id = 'tokenizer-toast';
        toast.innerHTML = `
            <style>
                #tokenizer-toast {
                    position: fixed;
                    bottom: 24px;
                    left: 50%;
                    transform: translateX(-50%) translateY(80px);
                    z-index: 999999;
                    background: #1a1a2e;
                    color: #00FF88;
                    border: 1px solid #00FF8844;
                    border-radius: 12px;
                    padding: 12px 24px;
                    font-family: 'Courier New', monospace;
                    font-size: 13px;
                    font-weight: 600;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.3), 0 0 20px rgba(0,255,136,0.1);
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    animation: toastSlideUp 0.3s ease forwards;
                    white-space: nowrap;
                }
                #tokenizer-toast .toast-key {
                    background: #2a2a4e;
                    border: 1px solid #444;
                    border-radius: 4px;
                    padding: 2px 8px;
                    font-size: 11px;
                    color: #FFAA00;
                }
                @keyframes toastSlideUp {
                    to { transform: translateX(-50%) translateY(0); }
                }
                @keyframes toastFadeOut {
                    to { transform: translateX(-50%) translateY(80px); opacity: 0; }
                }
            </style>
            <span>${message}</span>
            <span class="toast-key">ALT+Y</span>
        `;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastFadeOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // =============================================
    // KEYBOARD SHORTCUT — ALT+Y
    // =============================================
    document.addEventListener('keydown', (e) => {
        if (e.altKey && (e.key === 'y' || e.key === 'Y')) {
            e.preventDefault();
            e.stopPropagation();
            copyJSON();
        }
    });

    // =============================================
    // INDICATOR — Badge visual que o script está ativo
    // =============================================
    function showIndicator() {
        const badge = document.createElement('div');
        badge.id = 'tokenizer-badge';
        badge.innerHTML = `
            <style>
                #tokenizer-badge {
                    position: fixed;
                    bottom: 12px;
                    right: 12px;
                    z-index: 99998;
                    background: #1a1a2e;
                    color: #666;
                    border: 1px solid #333;
                    border-radius: 8px;
                    padding: 6px 12px;
                    font-family: 'Courier New', monospace;
                    font-size: 11px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    cursor: pointer;
                    transition: all 0.2s;
                    opacity: 0.5;
                }
                #tokenizer-badge:hover {
                    opacity: 1;
                    color: #00FF88;
                    border-color: #00FF8844;
                    box-shadow: 0 0 12px rgba(0,255,136,0.1);
                }
                #tokenizer-badge .badge-dot {
                    width: 6px;
                    height: 6px;
                    border-radius: 50%;
                    background: #00FF88;
                    animation: badgePulse 2s infinite;
                }
                @keyframes badgePulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.3; }
                }
            </style>
            <span class="badge-dot"></span>
            <span>📋 Tokenizer ativo</span>
            <span style="color:#FFAA00; font-weight:700;">ALT+Y</span>
        `;
        badge.addEventListener('click', () => copyJSON());
        document.body.appendChild(badge);
    }

    // Init
    showIndicator();
    console.log('[Tokenizer] 📋 MeliTools History Tokenizer v1.0.0 carregado. Pressione ALT+Y para copiar JSON.');

})();