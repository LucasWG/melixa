// ==UserScript==
// @name         Sauron - Auto Scroll to Shipment
// @namespace    https://debugzone.com.br/
// @version      1.2.0
// @description  Auto scroll até o envio correto (Seller ID) + Debug toggle com persistência.
// @author       LucasWG
// @match        https://shipping-bo.adminml.com/sauron/shipments/shipment/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    // ============================
    // ⚙️ CONFIG
    // ============================
    const STORAGE_KEY = 'sauron_autoscroll_debug';
    let DEBUG_ENABLED = localStorage.getItem(STORAGE_KEY) !== 'false'; // default: true na primeira vez

    // ============================
    // 🔧 DEBUG MODAL
    // ============================
    const logs = [];
    let modalEl = null;
    let logContainer = null;
    let fabEl = null;
    let overlayEl = null;
    let toggleBtn = null;

    function createDebugModal() {
        // Overlay
        overlayEl = document.createElement('div');
        overlayEl.id = 'debug-overlay';
        Object.assign(overlayEl.style, {
            position: 'fixed', top: '0', left: '0',
            width: '100vw', height: '100vh',
            backgroundColor: 'rgba(0,0,0,0.5)',
            zIndex: '999998', display: 'none'
        });
        overlayEl.addEventListener('click', () => toggleDebugModal(false));
        document.body.appendChild(overlayEl);

        // Modal
        modalEl = document.createElement('div');
        modalEl.id = 'debug-modal';
        Object.assign(modalEl.style, {
            position: 'fixed', bottom: '70px', right: '16px',
            width: '520px', maxHeight: '70vh',
            backgroundColor: '#1a1a2e', color: '#eee',
            borderRadius: '12px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
            zIndex: '999999', display: 'none', flexDirection: 'column',
            fontFamily: 'Consolas, Monaco, "Courier New", monospace',
            fontSize: '12px', overflow: 'hidden', border: '1px solid #333'
        });

        // Header
        const header = document.createElement('div');
        Object.assign(header.style, {
            padding: '10px 16px', backgroundColor: '#FFE600', color: '#333',
            fontWeight: 'bold', fontSize: '13px',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            borderBottom: '1px solid #333', gap: '8px'
        });
        header.innerHTML = `<span>🐛 Debug Log</span>`;

        // Container dos botões do header
        const headerBtns = document.createElement('div');
        Object.assign(headerBtns.style, { display: 'flex', gap: '8px', alignItems: 'center' });

        // Toggle debug ON/OFF
        toggleBtn = document.createElement('button');
        Object.assign(toggleBtn.style, {
            padding: '3px 10px', borderRadius: '6px', border: '1px solid #333',
            fontSize: '11px', cursor: 'pointer', fontWeight: 'bold',
            transition: 'all 0.2s ease'
        });
        updateToggleBtnStyle();
        toggleBtn.addEventListener('click', () => {
            DEBUG_ENABLED = !DEBUG_ENABLED;
            localStorage.setItem(STORAGE_KEY, DEBUG_ENABLED);
            updateToggleBtnStyle();
            log(`Debug ${DEBUG_ENABLED ? 'ATIVADO' : 'DESATIVADO'}. Preferência salva.`, DEBUG_ENABLED ? 'success' : 'warn');
        });
        headerBtns.appendChild(toggleBtn);

        // Botão limpar logs
        const clearBtn = document.createElement('button');
        Object.assign(clearBtn.style, {
            padding: '3px 10px', borderRadius: '6px', border: '1px solid #333',
            fontSize: '11px', cursor: 'pointer', backgroundColor: '#e74c3c',
            color: '#fff', fontWeight: 'bold'
        });
        clearBtn.textContent = '🗑 Limpar';
        clearBtn.addEventListener('click', () => {
            logs.length = 0;
            if (logContainer) logContainer.innerHTML = '';
        });
        headerBtns.appendChild(clearBtn);

        // Botão fechar
        const closeBtn = document.createElement('button');
        Object.assign(closeBtn.style, {
            background: 'none', border: 'none', color: '#333',
            fontSize: '18px', cursor: 'pointer', fontWeight: 'bold'
        });
        closeBtn.textContent = '✕';
        closeBtn.addEventListener('click', () => toggleDebugModal(false));
        headerBtns.appendChild(closeBtn);

        header.appendChild(headerBtns);
        modalEl.appendChild(header);

        // Log container
        logContainer = document.createElement('div');
        Object.assign(logContainer.style, {
            padding: '12px 16px', overflowY: 'auto', flex: '1',
            maxHeight: 'calc(70vh - 50px)'
        });
        modalEl.appendChild(logContainer);
        document.body.appendChild(modalEl);

        // FAB
        fabEl = document.createElement('button');
        fabEl.id = 'debug-fab';
        Object.assign(fabEl.style, {
            position: 'fixed', bottom: '16px', right: '16px',
            width: '50px', height: '50px', borderRadius: '50%',
            backgroundColor: '#FFE600', color: '#333', border: 'none',
            fontSize: '22px', cursor: 'pointer', zIndex: '999999',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'transform 0.2s ease'
        });
        fabEl.textContent = '🐛';
        fabEl.addEventListener('mouseenter', () => fabEl.style.transform = 'scale(1.1)');
        fabEl.addEventListener('mouseleave', () => fabEl.style.transform = 'scale(1)');
        fabEl.addEventListener('click', () => {
            const isVisible = modalEl.style.display === 'flex';
            toggleDebugModal(!isVisible);
        });
        document.body.appendChild(fabEl);

        // Se debug desativado, esconder o FAB por padrão
        if (!DEBUG_ENABLED) {
            fabEl.style.display = 'none';
        }
    }

    function updateToggleBtnStyle() {
        if (!toggleBtn) return;
        if (DEBUG_ENABLED) {
            toggleBtn.textContent = '🟢 Debug ON';
            toggleBtn.style.backgroundColor = '#2ecc71';
            toggleBtn.style.color = '#fff';
        } else {
            toggleBtn.textContent = '🔴 Debug OFF';
            toggleBtn.style.backgroundColor = '#555';
            toggleBtn.style.color = '#ccc';
        }
    }

    function toggleDebugModal(show) {
        if (modalEl) modalEl.style.display = show ? 'flex' : 'none';
        if (overlayEl) overlayEl.style.display = show ? 'block' : 'none';
    }

    function log(msg, type = 'info') {
        // Se debug desativado, só logar success/error (essenciais)
        if (!DEBUG_ENABLED && !['success', 'error'].includes(type)) return;

        const timestamp = new Date().toLocaleTimeString('pt-BR');
        logs.push({ timestamp, msg, type });

        if (!DEBUG_ENABLED) return; // Não renderizar no modal

        if (logContainer) {
            const line = document.createElement('div');
            Object.assign(line.style, {
                padding: '4px 0', borderBottom: '1px solid rgba(255,255,255,0.07)',
                lineHeight: '1.5', wordBreak: 'break-all'
            });
            const colors = {
                info: '#8be9fd', success: '#50fa7b', warn: '#f1fa8c',
                error: '#ff5555', debug: '#bd93f9', step: '#ffb86c'
            };
            const icons = {
                info: 'ℹ️', success: '✅', warn: '⚠️',
                error: '❌', debug: '🔍', step: '👉'
            };
            line.innerHTML = `
                <span style="color:#6c7293;">[${timestamp}]</span>
                <span>${icons[type] || ''}</span>
                <span style="color:${colors[type] || '#eee'};">${msg}</span>
            `;
            logContainer.appendChild(line);
            logContainer.scrollTop = logContainer.scrollHeight;
        }
    }

    // ============================
    // 🎯 LÓGICA PRINCIPAL
    // ============================

    createDebugModal();

    // Só abrir modal automaticamente se debug estiver ativado
    if (DEBUG_ENABLED) {
        toggleDebugModal(true);
    }

    log('Script iniciado.', 'info');
    log(`URL: ${window.location.href}`, 'debug');
    log(`Debug: ${DEBUG_ENABLED ? 'ATIVADO' : 'DESATIVADO'}`, 'info');

    // 1) Extrair ID da URL
    const urlMatch = window.location.pathname.match(/\/shipment\/(\d+)$/);
    if (!urlMatch) {
        log('Não foi possível extrair shipment ID da URL.', 'error');
        return;
    }
    const targetId = urlMatch[1];
    log(`Shipment ID alvo: ${targetId}`, 'success');

    // 2) Busca e scroll
    let attemptCount = 0;
    let found = false;

    function searchForShipment() {
        attemptCount++;
        log(`--- Tentativa #${attemptCount} ---`, 'step');

        // Buscar via TreeWalker todos os text nodes que contêm o ID
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        let matchedElements = [];
        let node;

        while ((node = walker.nextNode())) {
            if (node.textContent.includes(targetId)) {
                const parent = node.parentElement;
                if (parent) matchedElements.push({ textNode: node, element: parent });
            }
        }

        log(`Matches encontrados: ${matchedElements.length}`, matchedElements.length > 0 ? 'success' : 'warn');

        if (matchedElements.length === 0) return false;

        // Logar todos os matches
        matchedElements.forEach((m, i) => {
            const el = m.element;
            const tag = el.tagName;
            const cls = el.className?.toString?.()?.substring(0, 80) || '';
            const text = m.textNode.textContent.trim().substring(0, 120);
            log(`  [${i}] <${tag} class="${cls}"> → "${text}"`, 'debug');
        });

        // Encontrar o match que está no contexto "Envio #ID"
        let envioMatch = matchedElements.find(m => {
            const text = m.textNode.textContent;
            return text.includes('Envio') || text.includes('envio') || text.includes('#' + targetId);
        });

        // Se não achou com "Envio", pegar o primeiro visível
        if (!envioMatch) {
            envioMatch = matchedElements.find(m => {
                const rect = m.element.getBoundingClientRect();
                return rect.height > 0 && rect.width > 0;
            }) || matchedElements[0];
        }

        log(`Match selecionado: "${envioMatch.textNode.textContent.trim().substring(0, 80)}"`, 'success');

        // Subir para encontrar o card/container principal do envio
        const card = findShipmentCard(envioMatch.element);
        if (!card) {
            log('Não encontrou card pai. Usando o elemento direto.', 'warn');
        }

        const shipmentCard = card || envioMatch.element;
        log(`Card do envio: <${shipmentCard.tagName}> h=${Math.round(shipmentCard.getBoundingClientRect().height)}px`, 'debug');

        // AGORA: dentro do card, procurar o "Seller ID" para fazer scroll até lá
        const sellerTarget = findSellerIdInCard(shipmentCard);

        if (sellerTarget) {
            log(`Seller ID encontrado! Fazendo scroll até ele...`, 'success');
            sellerTarget.scrollIntoView({ behavior: 'smooth', block: 'center' });
            highlightElement(sellerTarget);
            log('🎉 SCROLL REALIZADO COM SUCESSO! (Seller ID)', 'success');
        } else {
            // Fallback: se não achar Seller ID, scroll até o final do card
            log('Seller ID não encontrado dentro do card. Fazendo scroll para o final do card...', 'warn');

            // Pegar o último filho do card para scroll
            const lastChild = shipmentCard.lastElementChild;
            if (lastChild) {
                lastChild.scrollIntoView({ behavior: 'smooth', block: 'center' });
                highlightElement(lastChild);
            } else {
                shipmentCard.scrollIntoView({ behavior: 'smooth', block: 'end' });
                highlightElement(shipmentCard);
            }
            log('🎉 SCROLL REALIZADO (fallback para final do card).', 'success');
        }

        return true;
    }

    /**
     * Dentro de um card de envio, procura o elemento que contém "Seller ID"
     */
    function findSellerIdInCard(card) {
        const walker = document.createTreeWalker(card, NodeFilter.SHOW_TEXT, null, false);
        let node;

        while ((node = walker.nextNode())) {
            if (/Seller\s*ID/i.test(node.textContent)) {
                const parent = node.parentElement;
                log(`  → Texto "Seller ID" encontrado em <${parent?.tagName}> class="${parent?.className?.toString?.()?.substring(0, 60)}"`, 'debug');

                // Subir um pouco para pegar o container do Seller (card do seller)
                let sellerCard = parent;
                let level = 0;
                while (sellerCard && level < 6) {
                    const rect = sellerCard.getBoundingClientRect();
                    // O container do Seller geralmente tem uma altura razoável e largura grande
                    if (rect.height > 60 && rect.width > 300 && level >= 1) {
                        log(`  → Seller container: <${sellerCard.tagName}> h=${Math.round(rect.height)} (nível ${level})`, 'debug');
                        return sellerCard;
                    }
                    sellerCard = sellerCard.parentElement;
                    level++;
                }

                // Se não achou container ideal, retorna o próprio pai
                return parent;
            }
        }

        // Fallback: procurar fora do card (a página pode ter estrutura diferente)
        log('  → Seller ID não encontrado dentro do card. Buscando globalmente após o card...', 'debug');

        // Pegar todos os elementos após o card que contêm "Seller ID"
        const allWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        let foundCard = false;

        while ((node = allWalker.nextNode())) {
            // Verificar se já passou pelo targetId
            if (node.textContent.includes(targetId)) {
                foundCard = true;
                continue;
            }

            // Depois do targetId, procurar Seller ID
            if (foundCard && /Seller\s*ID/i.test(node.textContent)) {
                const parent = node.parentElement;
                log(`  → Seller ID encontrado globalmente após o envio: <${parent?.tagName}>`, 'debug');

                let sellerCard = parent;
                let level = 0;
                while (sellerCard && level < 6) {
                    const rect = sellerCard.getBoundingClientRect();
                    if (rect.height > 60 && rect.width > 300 && level >= 1) {
                        return sellerCard;
                    }
                    sellerCard = sellerCard.parentElement;
                    level++;
                }
                return parent;
            }

            // Se encontrar outro shipment ID diferente, parar (saiu do escopo do envio alvo)
            if (foundCard && /Envio\s*#\d+/i.test(node.textContent) && !node.textContent.includes(targetId)) {
                log('  → Chegou ao próximo envio sem achar Seller ID.', 'warn');
                break;
            }
        }

        return null;
    }

    /**
     * Sobe na árvore DOM para encontrar o card principal do envio
     */
    function findShipmentCard(el) {
        let current = el.parentElement;
        let level = 0;
        let bestCandidate = null;

        while (current && level < 20) {
            const tag = current.tagName?.toLowerCase();
            const cls = current.className?.toString?.() || '';
            const rect = current.getBoundingClientRect();

            if (level <= 8) {
                log(`  ↑ Nível ${level}: <${current.tagName}> class="${cls.substring(0, 50)}" h=${Math.round(rect.height)}`, 'debug');
            }

            if (
                tag === 'section' || tag === 'article' ||
                /card|shipment|envio|package|panel/i.test(cls)
            ) {
                bestCandidate = current;
            }

            // Container grande que provavelmente engloba todo o envio
            if (rect.height > 400 && rect.width > 300 && !bestCandidate) {
                bestCandidate = current;
            }

            // Se ficou muito grande (tipo o body), parar
            if (rect.height > window.innerHeight * 2) {
                break;
            }

            current = current.parentElement;
            level++;
        }

        return bestCandidate;
    }

    function highlightElement(el) {
        const orig = {
            outline: el.style.outline,
            transition: el.style.transition,
            bg: el.style.backgroundColor
        };
        el.style.transition = 'outline 0.3s ease, background-color 0.3s ease';
        el.style.outline = '3px solid #FFE600';
        el.style.backgroundColor = 'rgba(255, 230, 0, 0.08)';
        setTimeout(() => {
            el.style.transition = 'outline 0.5s ease, background-color 0.5s ease';
            el.style.outline = orig.outline;
            el.style.backgroundColor = orig.bg;
            setTimeout(() => { el.style.transition = orig.transition; }, 500);
        }, 3000);
    }

    // ============================
    // 🔁 LOOP DE TENTATIVAS
    // ============================

    log('Iniciando busca...', 'info');

    if (searchForShipment()) {
        found = true;
        return;
    }

    const maxAttempts = 40;
    const intervalMs = 300;

    const observer = new MutationObserver(() => {
        if (!found && DEBUG_ENABLED) {
            log('MutationObserver: DOM alterado.', 'debug');
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    let attempts = 0;
    const interval = setInterval(() => {
        if (found) {
            clearInterval(interval);
            observer.disconnect();
            return;
        }
        attempts++;
        if (attempts > maxAttempts) {
            clearInterval(interval);
            observer.disconnect();
            log(`Limite de tentativas atingido. Elemento não encontrado.`, 'error');
            return;
        }
        found = searchForShipment();
        if (found) {
            clearInterval(interval);
            observer.disconnect();
        }
    }, intervalMs);

})();